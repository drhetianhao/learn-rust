pub struct Employee {
    pub name: String,
    pub salary: u64,
    pub fulltime: bool
}