pub trait Print {
    fn print(&self);     
}