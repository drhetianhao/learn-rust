pub enum Color {
    Red,
    Green,
    Blue
}

pub enum HouseLocation {
    Number(i32),
    Name(String),
    Unknown
}