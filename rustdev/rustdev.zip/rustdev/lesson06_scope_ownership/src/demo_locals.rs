pub fn do_it() {
	
    println!("\nIn demo_locals::do_it()");

	let x = 42;

	if x != 0 {
		let s1 = "Andy";
		println!("s1: {}", s1);
	}
	
	// Nope:
	// println!("s1 {}", s1);
}