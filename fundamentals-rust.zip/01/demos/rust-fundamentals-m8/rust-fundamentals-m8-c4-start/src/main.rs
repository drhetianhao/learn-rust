#![allow(unused)]

fn main() {
    write_message();
}

fn write_message() {
    let name = "Duck Airlines";
    let slogan = "We hit the ground every time.";
    println!("Welcome to {}. {}", name, slogan);
}
