#![allow(unused_variables)]

fn main() {
    let first_value = 10;
    let second_value = 15;
    let results = first_value > second_value;

    println!("{}", results);
}
