#![allow(unused_variables)]

fn main() {
    let are_equal_is_true = 1 == 1;
    let are_equal_is_false = 1 == 2;
    let are_not_equal = 1 != 2;

    let is_true = true;
    let is_false = !is_true;
    println!("is_true: {}, is_false: {}", is_true, is_false);
}
