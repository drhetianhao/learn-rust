
fn main() {
    let outer_scope = 412;
}
