#![allow(unused_variables)]

fn main() {
    let scope_test = "outer scope";
    let scope_test = 0;
    println!("{}", scope_test);
}
