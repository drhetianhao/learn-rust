#![allow(unused_variables)]

fn main() {

}
