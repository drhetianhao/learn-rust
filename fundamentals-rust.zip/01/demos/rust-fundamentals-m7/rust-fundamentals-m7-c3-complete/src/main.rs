
fn main() {
    let original = String::from("original value");
    println!("\noriginal: \t\"{}\"", original);

    let next = original;
    println!("{}", original);
}
