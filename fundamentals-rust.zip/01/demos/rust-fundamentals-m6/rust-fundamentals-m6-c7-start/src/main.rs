
fn main() {
    let animal = "Duck";

    match animal {
        "Duck" => {
            println!("Quack");
        }
        _ => {
            println!("All quiet out here");
        }
    }
}
