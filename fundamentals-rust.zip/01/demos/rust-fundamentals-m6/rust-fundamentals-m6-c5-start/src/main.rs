
fn main() {
    let animal = "Duck";
    if animal == "Duck" {
        println!("Quack");
    } else if animal == "Dog" {
        println!("Bark");
    } else {
        println!("All quiet out here");
    }
}
