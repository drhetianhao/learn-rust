
fn main() {
    let animal = "Duck";
    match animal {
        "Duck" => println!("Quack"),
        "Dog" => println!("Bark"),
        _ => println!("All quiet out here")
    }
}
