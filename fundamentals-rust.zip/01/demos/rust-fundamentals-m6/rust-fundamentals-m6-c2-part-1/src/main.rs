
fn main() {
    let word = "Dog";
    if word == "Duck" {
        println!("Quack");
    } else if word == "Dog" {
        println!("Bark");
    } else {
        println!("All quiet out here");
    }
}
