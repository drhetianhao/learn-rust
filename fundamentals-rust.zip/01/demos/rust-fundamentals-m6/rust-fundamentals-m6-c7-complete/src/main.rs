
fn main() {
    let animal = "Duck";

    if let animal = "Duck" {
        println!("Quack");
    }
}
