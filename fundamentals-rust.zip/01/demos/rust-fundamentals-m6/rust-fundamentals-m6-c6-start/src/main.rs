
enum NavigationAids {
    NDB(u16),
    VOR(String, f32),
    VORDME(String, f32),
    FIX{name: String, latitude: f32, longitude: F32}
}

fn main() {

}
