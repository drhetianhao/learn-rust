
fn main() {
    let mut counter = 0;

    while counter <= 10 {
        counter += 1;
        println!("{}", counter);
    }
}
