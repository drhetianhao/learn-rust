#![allow (unused)]

fn main() {
    const EARTH_RADIUS_IN_KILOMETERS: f64 = 6371.0;

}