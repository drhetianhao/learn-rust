#![allow(unused_variables)]

fn main() {
    let duck = "Duck";
    let airlines = "Airlines";

    let airline_name = format!("{} {}", duck, airlines);
    println!("{}", airline_name);
}
