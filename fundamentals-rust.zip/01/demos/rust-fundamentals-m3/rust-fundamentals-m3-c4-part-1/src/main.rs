#![allow(unused_variables)]

fn main() {
    let location = ("KCLE", 41.4094069, -81.8546911);
    println!("Location name: {}, latitude: {}, longitude: {}",
             location.0, location.1, location.2);
}
