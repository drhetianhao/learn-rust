#![allow(unused_variables)]

fn main() {
    let person_name_slice = "Donald Mallard";
    let person_name_string = person_name_slice.to_string();
}
