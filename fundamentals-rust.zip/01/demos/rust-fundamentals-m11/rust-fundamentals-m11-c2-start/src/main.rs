
#[derive(Debug)]
struct NdbNavAid {
    name: String,
    frequency: u16
}

#[derive(Debug)]
struct VorNavAid {
    name: String,
    frequency: f32
}

fn main() {

}
