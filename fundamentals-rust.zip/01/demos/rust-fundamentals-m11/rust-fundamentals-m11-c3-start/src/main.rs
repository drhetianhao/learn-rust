#![allow(unused)]
use::std::ops::Add;

fn main() {
    let sum = add(256, 262);
    println!("{}", sum);
}
